# ex-binary-prof
Binary counting exercise
