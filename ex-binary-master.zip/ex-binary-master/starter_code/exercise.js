var exercise = {};


// number is the value you entered before clicking convert
exercise.fingers = function(number) {

    var answer = {
        thumbFinger: 'off',
        indexFinger: 'off',
        middleFinger: 'off',
        ringFinger: 'off',
        pinkyFinger: 'off'
    };

    // ------------------------------------------------------
    // YOUR CODE:
    //   Your code needs to return the answer object
    //   with the right values for the given number
    //
    //   Example: for a number value of 7, the answer is
    //
    //      var answer = {
    //          thumbFinger  : 'on',
    //          indexFinger  : 'on',
    //          middleFinger : 'on',
    //          ringFinger   : 'off',
    //          pinkyFinger  : 'off'
    //      };
    //
    // ------------------------------------------------------

    return answer;
};